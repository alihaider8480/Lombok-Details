package com.spring.springTest.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.springTest.Services.UserServies;
import com.spring.springTest.dto.UserDTO;

@RestController
public class Home 
{
	@Autowired
	UserServies userServies;
	
	@GetMapping("/findAll")
	public List<UserDTO> findAllUser()
	{
		return userServies.findAll();
	}
	
	@GetMapping("/insertUser")
	public int insertUser()
	{
		UserDTO userDto = new UserDTO();
		userDto.setId(6L);
		userDto.setName("Nadeem Raza");
		userDto.setAddress("Gulshan");
		
		return userServies.insert(userDto);
	}
	
	@GetMapping("/updateUser")
	public int updateUser()
	{
		UserDTO userDto = new UserDTO();
		userDto.setId(6L);
		userDto.setName("Nadeem Ahmed");
		userDto.setAddress("DHA V Khi");
		
		return userServies.update(userDto);
	}
	
	@GetMapping("/deleteUser")
	public int deleteUser()
	{
		UserDTO userDto = new UserDTO();
		userDto.setId(6L);
		return userServies.delete(userDto.getId());
	}
}
